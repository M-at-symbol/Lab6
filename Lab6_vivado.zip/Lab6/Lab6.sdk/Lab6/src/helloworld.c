#include "platform.h"
#include "xparameters.h"
#include "xstatus.h"
#include "stdio.h"
#include "xgpio.h"

#define GPIO_INC_DEVICE_ID  XPAR_INC_DEVICE_ID//Gets memory address for the INC GPIO.
#define GPIO_U_D_DEVICE_ID  XPAR_U_D_DEVICE_ID//Gets memory address for the U_D GPIO.
#define GPIO_BTN_DEVICE_ID  XPAR_BTN_DEVICE_ID//Gets memory address for the BTN GPIO.
#define CHANNEL 1

void wasteCycles(int cycles);

int main(){

	init_platform();
	XGpio inc, u_d, btn;


	//initialize all GPIOs used
	XGpio_Initialize(&inc, GPIO_INC_DEVICE_ID);
	XGpio_Initialize(&u_d, GPIO_U_D_DEVICE_ID);
	XGpio_Initialize(&btn, GPIO_BTN_DEVICE_ID);
	XGpio_DiscreteWrite(&inc, CHANNEL, 1);


	while(1){
		char upDown;
		scanf("%c", &upDown);
		switch (upDown){
		case 'i':
			XGpio_DiscreteWrite(&u_d, CHANNEL, 0);//start with 0 to ensure the wipe goes to the H terminal
			XGpio_DiscreteWrite(&inc, CHANNEL, 0);
			wasteCycles(10000000);
			XGpio_DiscreteWrite(&inc, CHANNEL, 1);
			printf("d\n");
			break;
		case 'd':
			for (int i=99; i>0; i--) { //use for loop to decrement through digital resistors 100 values
				XGpio_DiscreteWrite(&u_d, CHANNEL, 1);
				XGpio_DiscreteWrite(&inc, CHANNEL, 0);
				wasteCycles(10000000);
				XGpio_DiscreteWrite(&inc, CHANNEL, 1);

			}
			printf("d\n");
			break;
		}
	}
	return 0;
}

void wasteCycles(int cycles){
	for(volatile int i = 0; i< cycles; ++i){}
}
