#include "platform.h"
#include "xparameters.h"
#include "xstatus.h"
#include "stdio.h"
#include "xgpio.h"

#define GPIO_INC_DEVICE_ID  XPAR_INC_DEVICE_ID//Gets memory address for the INC GPIO.
#define GPIO_U_D_DEVICE_ID  XPAR_U_D_DEVICE_ID//Gets memory address for the U_D GPIO.
#define GPIO_BTN_DEVICE_ID  XPAR_BTN_DEVICE_ID//Gets memory address for the BTN GPIO.
#define CHANNEL 1

void wasteCycles(int cycles); //waste cycles for delay

int main(){

	init_platform();
	XGpio inc, u_d, btn;


	//initialize all GPIOs used
	XGpio_Initialize(&inc, GPIO_INC_DEVICE_ID);
	XGpio_Initialize(&u_d, GPIO_U_D_DEVICE_ID);
	XGpio_Initialize(&btn, GPIO_BTN_DEVICE_ID);
	XGpio_DiscreteWrite(&inc, CHANNEL, 1);


	while(1){
		char upDown;
		scanf("%c", &upDown); //scan for character from serial port
		switch (upDown){ //switch statement
		case 'i': //if char = 'i'
			XGpio_DiscreteWrite(&u_d, CHANNEL, 0);//start with 0 to ensure the wipe goes to the H terminal
			XGpio_DiscreteWrite(&inc, CHANNEL, 0);//set low to begin pulse
			wasteCycles(10000000); //delay
			XGpio_DiscreteWrite(&inc, CHANNEL, 1);//set high to end pulse
			printf("d\n");
			break;
		case 'd': //if char = 'd'
			for (int i=99; i>0; i--) { //use for loop to decrement through digital resistors 100 values
				XGpio_DiscreteWrite(&u_d, CHANNEL, 1);//start with 1 to ensure the wiper goes to the L terminal
				XGpio_DiscreteWrite(&inc, CHANNEL, 0);//set low to begin pulse
				wasteCycles(10000000);//delay
				XGpio_DiscreteWrite(&inc, CHANNEL, 1);//set high to end pulse

			}
			printf("d\n");
			break;
		}
	}
	return 0;
}

void wasteCycles(int cycles){
	for(volatile int i = 0; i< cycles; ++i){} ;  //waste cycles
}
